package Clases;

public class Tablero {
    private Navegador Nav;
    public int[][] tablero3x3;
    public int[][] tablero4x4;
    public int[][] tablero5x5;

    public Tablero(int[][] tablero3x3, int[][] tablero4x4, int[][] tablero5x5) {
        this.tablero3x3 = new int[3][3];
        this.tablero4x4 = new int[4][4];
        this.tablero5x5 = new int[5][5];
    }

    public Tablero(Navegador n) {
        Nav = n;
    }

    public Navegador getNav() {
        return Nav;
    }

    public void setNav(Navegador Nav) {
        this.Nav = Nav;
    }

    public int[][] getTablero3x3() {
        return tablero3x3;
    }

    public void setTablero3x3(int[][] tablero3x3) {
        this.tablero3x3 = tablero3x3;
    }

    public int[][] getTablero4x4() {
        return tablero4x4;
    }

    public void setTablero4x4(int[][] tablero4x4) {
        this.tablero4x4 = tablero4x4;
    }

    public int[][] getTablero5x5() {
        return tablero5x5;
    }

    public void setTablero5x5(int[][] tablero5x5) {
        this.tablero5x5 = tablero5x5;
    }

    @Override
    public String toString() {
        return "Tablero{" + "Nav=" + Nav + ", tablero3x3=" + tablero3x3 + ", tablero4x4=" + tablero4x4 + ", tablero5x5=" + tablero5x5 + '}';
    }
    public void setValor3x3(int fila, int columna, int valor) {
        if (fila >= 0 && fila < 3 && columna >= 0 && columna < 3) {
            tablero3x3[fila][columna] = valor;
        } else {
            System.out.println("Posición inválida. Inténtalo de nuevo.");
        }
        System.out.println(tablero3x3[0][0]);
    }
    public void imprimirMatriz() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(tablero3x3[i][j] + " ");
            }
            System.out.println();
        }
    }

    

    public void colocarFicha(){
        switch(Nav.gui.cbTablero.getSelectedIndex()){
                    case 0:
                        if(Nav.vista1.txtTurno.getText() == "X"){
                            Nav.vista1.txtTurno.setText("O");
                            break;
                        } else {
                            Nav.vista1.txtTurno.setText("X");
                            break;
                        }
                    case 1:
                        if(Nav.vista2.txtTurno.getText() == "X"){
                            Nav.vista2.txtTurno.setText("O");
                            break;
                        } else {
                            Nav.vista2.txtTurno.setText("X");
                            break;
                        }
                    case 2:
                        if(Nav.vista3.txtTurno.getText() == "X"){
                            Nav.vista3.txtTurno.setText("O");
                            break;
                        } else {
                            Nav.vista3.txtTurno.setText("X");
                            break;
                        }
                    }
    }
    
    public void reiniciarTablero(){
        switch(Nav.gui.cbTablero.getSelectedIndex()){
                    case 0:
                        Nav.vista1.btn01.setText("");
                        Nav.vista1.btn02.setText("");
                        Nav.vista1.btn03.setText("");
                        Nav.vista1.btn04.setText("");
                        Nav.vista1.btn05.setText("");
                        Nav.vista1.btn06.setText("");
                        Nav.vista1.btn07.setText("");
                        Nav.vista1.btn08.setText("");
                        Nav.vista1.btn09.setText("");
                        Nav.vista1.btn01.setEnabled(true);
                        Nav.vista1.btn02.setEnabled(true);
                        Nav.vista1.btn03.setEnabled(true);
                        Nav.vista1.btn04.setEnabled(true);
                        Nav.vista1.btn05.setEnabled(true);
                        Nav.vista1.btn06.setEnabled(true);
                        Nav.vista1.btn07.setEnabled(true);
                        Nav.vista1.btn08.setEnabled(true);
                        Nav.vista1.btn09.setEnabled(true);
                        Nav.vista1.setMovimientos(0);
                        for (int i = 0; i < 3; i++) {
                            for (int j = 0; j < 3; j++) {
                                Nav.vista1.tab3x3[i][j] = 0;
                            }
                        }
                        System.out.println("Eliminado con éxito.");
                        break;
                    case 1:
                        Nav.vista2.btn01.setText("");
                        Nav.vista2.btn02.setText("");
                        Nav.vista2.btn03.setText("");
                        Nav.vista2.btn04.setText("");
                        Nav.vista2.btn05.setText("");
                        Nav.vista2.btn06.setText("");
                        Nav.vista2.btn07.setText("");
                        Nav.vista2.btn08.setText("");
                        Nav.vista2.btn09.setText("");
                        Nav.vista2.btn10.setText("");
                        Nav.vista2.btn11.setText("");
                        Nav.vista2.btn12.setText("");
                        Nav.vista2.btn13.setText("");
                        Nav.vista2.btn14.setText("");
                        Nav.vista2.btn15.setText("");
                        Nav.vista2.btn16.setText("");
                        Nav.vista2.btn01.setEnabled(true);
                        Nav.vista2.btn02.setEnabled(true);
                        Nav.vista2.btn03.setEnabled(true);
                        Nav.vista2.btn04.setEnabled(true);
                        Nav.vista2.btn05.setEnabled(true);
                        Nav.vista2.btn06.setEnabled(true);
                        Nav.vista2.btn07.setEnabled(true);
                        Nav.vista2.btn08.setEnabled(true);
                        Nav.vista2.btn09.setEnabled(true);
                        Nav.vista2.btn10.setEnabled(true);
                        Nav.vista2.btn11.setEnabled(true);
                        Nav.vista2.btn12.setEnabled(true);
                        Nav.vista2.btn13.setEnabled(true);
                        Nav.vista2.btn14.setEnabled(true);
                        Nav.vista2.btn15.setEnabled(true);
                        Nav.vista2.btn16.setEnabled(true);
                        Nav.vista2.setMovimientos(0);
                        for (int i = 0; i < 4 ; i++) {
                            for (int j = 0; j < 4; j++) {
                                Nav.vista2.tab4x4[i][j] = 0;
                            }
                        }
                        System.out.println("Eliminado con éxito");
                        break;
                    case 2:
                        Nav.vista3.btn01.setText("");
                        Nav.vista3.btn02.setText("");
                        Nav.vista3.btn03.setText("");
                        Nav.vista3.btn04.setText("");
                        Nav.vista3.btn05.setText("");
                        Nav.vista3.btn06.setText("");
                        Nav.vista3.btn07.setText("");
                        Nav.vista3.btn08.setText("");
                        Nav.vista3.btn09.setText("");
                        Nav.vista3.btn10.setText("");
                        Nav.vista3.btn11.setText("");
                        Nav.vista3.btn12.setText("");
                        Nav.vista3.btn13.setText("");
                        Nav.vista3.btn14.setText("");
                        Nav.vista3.btn15.setText("");
                        Nav.vista3.btn16.setText("");
                        Nav.vista3.btn17.setText("");
                        Nav.vista3.btn18.setText("");
                        Nav.vista3.btn19.setText("");
                        Nav.vista3.btn20.setText("");
                        Nav.vista3.btn21.setText("");
                        Nav.vista3.btn22.setText("");
                        Nav.vista3.btn23.setText("");
                        Nav.vista3.btn24.setText("");
                        Nav.vista3.btn25.setText("");
                        Nav.vista3.btn01.setEnabled(true);
                        Nav.vista3.btn02.setEnabled(true);
                        Nav.vista3.btn03.setEnabled(true);
                        Nav.vista3.btn04.setEnabled(true);
                        Nav.vista3.btn05.setEnabled(true);
                        Nav.vista3.btn06.setEnabled(true);
                        Nav.vista3.btn07.setEnabled(true);
                        Nav.vista3.btn08.setEnabled(true);
                        Nav.vista3.btn09.setEnabled(true);
                        Nav.vista3.btn10.setEnabled(true);
                        Nav.vista3.btn11.setEnabled(true);
                        Nav.vista3.btn12.setEnabled(true);
                        Nav.vista3.btn13.setEnabled(true);
                        Nav.vista3.btn14.setEnabled(true);
                        Nav.vista3.btn15.setEnabled(true);
                        Nav.vista3.btn16.setEnabled(true);
                        Nav.vista3.btn17.setEnabled(true);
                        Nav.vista3.btn18.setEnabled(true);
                        Nav.vista3.btn19.setEnabled(true);
                        Nav.vista3.btn20.setEnabled(true);
                        Nav.vista3.btn21.setEnabled(true);
                        Nav.vista3.btn22.setEnabled(true);
                        Nav.vista3.btn23.setEnabled(true);
                        Nav.vista3.btn24.setEnabled(true);
                        Nav.vista3.btn25.setEnabled(true);
                        Nav.vista3.setMovimientos(0);
                        for (int i = 0; i < 5; i++) {
                            for (int j = 0; j < 5; j++) {
                                Nav.vista3.tab5x5[i][j] = 0;
                            }
                        }
                        System.out.println("Eliminado con éxito");
                        break;
                    }
    }
}
