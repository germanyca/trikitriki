package Clases;

import Vista.*;

public class Navegador {
    public Juego game;
    public Jugador player;
    public Tablero board;
    public Index gui;
    public Default vista1;
    public Second vista2;
    public Tab5x5 vista3;

    public Navegador() {
        game = new Juego(this);
        player = new Jugador(this);
        board = new Tablero(this);
        gui = new Index(this);
        vista1 = new Default(this);
        vista2 = new Second(this);
        vista3 = new Tab5x5(this);
    }
    
}
