
import Clases.*;
import Vista.*;

public class Main {
    public static void main(String[] args) {
        Navegador Nav = new Navegador();
        Nav.gui.setVisible(true);
    }
}
